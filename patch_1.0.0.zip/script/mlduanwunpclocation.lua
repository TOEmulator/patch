function GetCurrentNpcLocation()
	return "NpcLocation"
end


NpcLocation = {}

--Ҫ���õ���npc�Ļ���������һ������
NpcLocation[0] = { 5056, 152, 532, 14 }
NpcLocation[1] = { 5057, 151, 535, 8 }
NpcLocation[2] = { 5057, 157, 531, 12 }
NpcLocation[3] = { 5057, 152, 525, 14 }
NpcLocation[4] = { 5057, 146, 530, 0 }
NpcLocation[5] = { 5055, 147, 531, 10 }
NpcLocation[6] = { 5055, 149, 533, 8 }
NpcLocation[7] = { 5055, 155, 531, 6 }
NpcLocation[8] = { 5055, 158, 532, 8 }
NpcLocation[9] = { 5055, 153, 526, 6 }
NpcLocation[10] = { 5055, 150, 527, 8 }
NpcLocation[11] = { 5053, 154, 529, 4 }
NpcLocation[12] = { 5053, 67, -400, 6 }
NpcLocation[13] = { 5056, 61, -401, 12 }
NpcLocation[14] = { 5057, 49, -400, 10 }
NpcLocation[15] = { 5057, 60, -410, 10 }
NpcLocation[16] = { 5057, 75, -404, 10 }
NpcLocation[17] = { 5057, 70, -391, 14 }
NpcLocation[18] = { 5055, 70, -393, 10 }
NpcLocation[19] = { 5055, 75, -402, 14 }
NpcLocation[20] = { 5055, 73, -404, 12 }
NpcLocation[21] = { 5055, 58, -412, 10}
NpcLocation[22] = { 5055, 57, -408, 8 }
NpcLocation[23] = { 5055, 63, -405, 6 }
NpcLocation[24] = { 5055, 59, -403, 10 }
NpcLocation[25] = { 5055, 63, -400, 8 }
NpcLocation[26] = { 5055, 59, -397, 6 }
NpcLocation[27] = { 5055, 51, -401, 8 }
NpcLocation[28] = { 5055, 49, -402, 8 }
NpcLocation[29] = { 5055, 50, -398, 6 }
NpcLocation[30] = { 5056, 1428, 1358, 0 }
NpcLocation[31] = { 5053, 1429, 1362, 2 }
NpcLocation[32] = { 5057, 1434, 1352, 10 }
NpcLocation[33] = { 5057, 1422, 1352, 2 }
NpcLocation[34] = { 5057, 1422, 1365, 6 }
NpcLocation[35] = { 5057, 1436, 1365, 10 }
NpcLocation[36] = { 5055, 1437, 1363, 6 }
NpcLocation[37] = { 5055, 1436, 1353, 6 }
NpcLocation[38] = { 5055, 1432, 1351, 6 }
NpcLocation[39] = { 5055, 1429, 1356, 6 }
NpcLocation[40] = { 5055, 1431, 1360, 2}
NpcLocation[41] = { 5055, 1427, 1360, 14}
NpcLocation[42] = { 5055, 1424, 1366, 2 }
NpcLocation[43] = { 5055, 1421, 1365, 12 }
NpcLocation[44] = { 5055, 1424, 1365, 10 }
NpcLocation[45] = { 5055, 1424, 1351, 8 }
NpcLocation[46] = { 5055, 1420, 1354, 12 }
NpcLocation[47] = { 5054, 111, -2052, 0 }
NpcLocation[48] = { 5058, 1465, 1352, 4 }
NpcLocation[49] = { 5059, 1465, 1365, 4 }
NpcLocation[50] = { 5058, 178, 515, 0 }
NpcLocation[51] = { 5059, 169, 515, 0 }
NpcLocation[52] = { 5058, 99, -422, 6 }
NpcLocation[53] = { 5059, 104, -417, 6 }