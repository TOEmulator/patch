function GetCurrentNpcLocation()
	return "NpcLocation"
end


NpcLocation = {}

--Ҫ���õ���npc�Ļ���������һ������

NpcLocation[0] = { 4519, 152, 531, 9 }
NpcLocation[1] = { 4519, 372, 1190, 9 }
NpcLocation[2] = { 4519, 280, -130, 4 }
NpcLocation[3] = { 4519, 276, -548, 0 }
NpcLocation[4] = { 4519, -259, -476, 10 }
NpcLocation[5] = { 4519, -582, -864, 14 }
NpcLocation[6] = { 4519, 22, -936, 2 }
NpcLocation[7] = { 4519, 39, -1631, 6 }
NpcLocation[8] = { 4519, 136, -2056, 6 }
NpcLocation[9] = { 4519, -581, -1738, 14 }
NpcLocation[10] = { 4519, -1125, -977, 14 }
NpcLocation[11] = { 4519, -1225, -1720, 2 }
NpcLocation[12] = { 4518, 375, 1188, 7 }
NpcLocation[13] = { 4518, 154, 528, 7 }
NpcLocation[14] = { 4518, 149, 532, 0 }
NpcLocation[15] = { 4518, 281, -126, 0 }
NpcLocation[16] = { 4518, 279, -545, 0 }
NpcLocation[17] = { 4518, 272, -550, 0 }
NpcLocation[18] = { 4518, 25, -940, 10 }
NpcLocation[19] = { 4518, 39, -1634, 7 }
NpcLocation[20] = { 4518, -579, -1735, 7 }
NpcLocation[21] = { 4518, 135, -2058, 15 }
NpcLocation[22] = { 4518, -583, -867, 7 }
NpcLocation[23] = { 4518, -257, -479, 7 }
NpcLocation[24] = { 4518, -1125, -996, 7 }
NpcLocation[25] = { 4518, -1123, -974, 15 }
NpcLocation[26] = { 4518, -1160, -979, 0 }
NpcLocation[27] = { 4519, -1165, -953, 11 }
NpcLocation[28] = { 4518, -1223, -1722, 5 }
NpcLocation[29] = { 4519, 852, -613, 1 }
NpcLocation[30] = { 4518, 855, -612, 4 }
NpcLocation[31] = { 4519, 1390, -426, 4 }
NpcLocation[32] = { 4518, 1391, -423, 2 }
NpcLocation[33] = { 4521, 141, 539, 8 }
NpcLocation[34] = { 4521, 282, -536, 8 }
NpcLocation[35] = { 4521, 49, -1633, 9 }
