function GetCurrentNpcLocation()
	return "NpcLocation"
end


NpcLocation = {}

--Ҫ���õ���npc�Ļ���������һ������

NpcLocation[0] = { 4641, 362, 1183, 0 }
NpcLocation[1] = { 4641, 359, 1183, 13 }
NpcLocation[2] = { 4641, 361, 1181, 4 }
NpcLocation[3] = { 4641, 359, 1181, 9 }
NpcLocation[4] = { 4637, 362, 1179, 6 }
NpcLocation[5] = { 4643, 365, 1183, 2 }
NpcLocation[6] = { 4641, 153, 531, 2 }
NpcLocation[7] = { 4641, 153, 529, 6 }
NpcLocation[8] = { 4641, 151, 528, 9 }
NpcLocation[9] = { 4641, 150, 530, 14 }
NpcLocation[10] = { 4637, 151, 532, 1 }
NpcLocation[11] = { 4643, 148, 530, 13 }
NpcLocation[12] = { 4641, 281, -544, 3 }
NpcLocation[13] = { 4641, 279, -543, 14 }
NpcLocation[14] = { 4641, 280, -546, 7 }
NpcLocation[15] = { 4641, 278, -545, 11 }
NpcLocation[16] = { 4637, 281, -542, 1 }
NpcLocation[17] = { 4643, 277, -543, 14 }
NpcLocation[18] = { 4641, 75, -1636, 14 }
NpcLocation[19] = { 4641, 76, -1638, 9 }
NpcLocation[20] = { 4641, 78, -1635, 1 }
NpcLocation[21] = { 4641, 78, -1637, 6 }
NpcLocation[22] = { 4643, 76, -1634, 15 }
NpcLocation[23] = { 4637, 74, -1638, 11 }
