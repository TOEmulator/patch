function GetCurrentNpcLocation()
	return "NpcLocation"
end


NpcLocation = {}

--Ҫ���õ���npc�Ļ���������һ������

NpcLocation[0] = { 5315, 84, -392, 8 }
NpcLocation[1] = { 5313, 422, 367, 8 }
NpcLocation[2] = { 5313, -413, -383, 8 }
NpcLocation[3] = { 5313, -214, -568, 8 }
NpcLocation[4] = { 5313, -547, -1053, 8 }
NpcLocation[5] = { 5313, -404, -1273, 8 }
NpcLocation[6] = { 5313, -1145, -1145, 8 }
NpcLocation[7] = { 5313, -940, -940, 8 }
NpcLocation[8] = { 5313, 550, -330, 8 }
NpcLocation[9] = { 5313, 1440, -440, 8 }